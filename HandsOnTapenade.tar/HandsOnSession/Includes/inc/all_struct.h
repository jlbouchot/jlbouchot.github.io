/* All structures used in our program */

#ifndef ALL_STRUCTS
#define ALL_STRUCTS

typedef struct point2dstruct_ {
    float x;
    float y;
    float* dist2zero;
} point2dstruct;

typedef float point2darray[2];

#endif