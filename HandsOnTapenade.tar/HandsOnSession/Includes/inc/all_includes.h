/* Main header file for our program */

#ifndef ALL_INCLUDES 
#define ALL_INCLUDES

#include <stdio.h>
#include "all_struct.h"
#include "prog_funcs.h"

#endif