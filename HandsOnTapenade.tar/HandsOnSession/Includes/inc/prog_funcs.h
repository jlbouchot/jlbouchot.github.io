/* Some functions for the program */

#include <math.h>
#include "all_struct.h"
#include <stdio.h>
#include <malloc.h>

static inline float computeDistance(point2darray pt) {
    return pt[0]*pt[0]+pt[1]*pt[1];
}

static inline int isInUnitDisk2dArray(point2darray pt) {
    float dsquare = computeDistance(pt);
    return dsquare <= 1;
}

static inline point2darray* struct2array(point2dstruct ptstruct) {
    point2darray* out = (point2darray*)malloc(sizeof(point2darray));
    (*out)[0] = ptstruct.x; 
    (*out)[1] = ptstruct.y;
    return out;
}

static inline int isInUnitDisk2dStruct(point2dstruct *pt) {
    /* Also sets the radius for the current point as struct */
    point2darray* pta = struct2array(*pt);
    float d2 = computeDistance(*pta);
    pt->dist2zero = (float *)malloc(sizeof(float));
    *(pt->dist2zero) = sqrt(d2);
    return d2 <= 1;
}

static inline float distA2B(point2dstruct *ptA, point2dstruct *ptB) {
    // Some useless code to compute the distance to the origin
    point2darray* pta = struct2array(*ptA);
    float d2 = computeDistance(*pta);
    ptA->dist2zero = (float *)malloc(sizeof(float));
    *(ptA->dist2zero) = sqrt(d2);
    point2darray* ptb = struct2array(*ptB);
    d2 = computeDistance(*ptb);
    ptB->dist2zero = (float *)malloc(sizeof(float));
    *(ptA->dist2zero) = sqrt(d2);

    // Actually compute the distance, reusing the computeDistance function
    point2darray ptDiff;
    ptDiff[0] = (*pta)[0] - (*ptb)[0]; 
    ptDiff[1] = (*pta)[1] - (*ptb)[1];
    return computeDistance(ptDiff);
}