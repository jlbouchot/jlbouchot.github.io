/* This test aims at two things: 
 * 
 * 1) Make sure the includes are properly used if needed
 * 2) Make sure we can differentiate inline functions with a .h file
 */

#include "inc/all_includes.h"
#include <malloc.h>

int main(int argc, char* argv[]) {
    /* Just some stuff to call the various functions */
    float x=1.0, y=3.0, u=-0.5, v=-0.25;

    point2darray pta;
    pta[0] = u;
    pta[1] = v;

    point2dstruct pts; 
    pts.x = x;
    pts.y = y;
    int isInUnit = isInUnitDisk2dStruct(&pts);
    if (isInUnit) {
        printf("Point (%f, %f) with radius %f is within the unit circle!\n", pts.x, pts.y, *(pts.dist2zero));
    } else {
        printf("Point (%f, %f) with radius %f is outside the unit circle!\n", pts.x, pts.y, *(pts.dist2zero));
    }

    isInUnit = isInUnitDisk2dArray(pta);

    if (isInUnit) {
        printf("Point (%f, %f) with radius %f is within the unit circle!\n", pta[0], pta[1], computeDistance(pta));
    } else {
        printf("Point (%f, %f) with radius %f is outside the unit circle!\n", pta[0], pta[1], computeDistance(pta));
    }

    // Now try computing the distance between two points as structs
    point2dstruct pts2; 
    pts2.x = u;
    pts2.y = v;
    float dAB = distA2B( &pts, &pts2);

    printf("Distance between both points is %f\n", dAB);
}

