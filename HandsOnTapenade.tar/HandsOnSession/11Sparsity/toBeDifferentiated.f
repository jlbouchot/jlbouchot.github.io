      subroutine top(i1,i2,i3,o1,o2,o3)
      real i1, i2, i3
      real o1, o2, o3
      real l1, l2, l3
c
      o3 = i3*i2
      call sub1(i1, i2, o1, o2)
      o3 = o3*o2
      o2 = i1*int(i2)
      o1 = o1*o2 + o1*sin(o3*i2+i1)
      if (o2.gt.42.0) then
         o1 = o1*o2*i2
      endif
      o3 = 2.0
      i2 = 5.0
      end

      subroutine sub1(i1, i2, o1, o2)
      real i1, i2
      real o1, o2
      real l1, l2
c
      l1 = i1*i2
      l2 = i1-3*i2
      o1 = l1/l2
      o2 = 35.0
      i1 = 99.0
      end


      program main

      real i1, i2, i3, o1, o2, o3 
      i1 = 1.0
      i2 = 2.0
      i3 = 3.0

      call top(i1, i2, i3, o1, o2, o3)

      print *, "O1 = ", o1, " -- O2 = ", o2, " -- O3 = ", o3

      end program main